silly little image thingy



set Reference.png as your reference image, 
run main.py and enter your palette (Choose from PresetColours folder and choose by folder name)
get new palletes from lospec.com using getLospecPallete.py
output is stored in Output folder / recentOutput.png