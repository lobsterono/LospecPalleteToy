#   Finds a palette from art website Lospec.com

import os
import requests
from bs4 import BeautifulSoup
import csv
from PIL import Image

URL = "https://lospec.com/palette-list/twilight-5"
palette_name = URL.split("/")[-1]
r = requests.get(URL)
soup = BeautifulSoup(r.content, 'html5lib')
cols=[]  # a list to store colours
table = list(soup.find_all("div", class_="palette")[0])
for i in range(len(table)):
    if(str(table[i])[0] == '<'):
        cols.append(str(str(table[i]).split("\n")[1].strip(" ")))
print(cols)

#   Make new folder in presets with the palette name
os.mkdir('PresetColours/'+palette_name)

for i in range(len(cols)):
    h = cols[i].lstrip('#')
    rgb = tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
    im = Image.new(mode="RGB", size=(5, 5), color = rgb)
    im.save('PresetColours/'+palette_name+"/"+str(i)+".png")