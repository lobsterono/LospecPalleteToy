from math import floor
import os
from PIL import Image
from colorthief import ColorThief
import numpy as np
from random import randint
import cv2
import numpy
import glob

palette = input("Colour Palette?\n")

def arrayConfidence(a,b):
    conf = []
    for i,e in enumerate(a):
        conf.append(abs(e - b[i]) if e < b[i] else abs(b[i] - e))
    return sum(conf)

def find_nearest(array, value):
    array = np.asarray(array)
    idx = (np.abs(array - value)).argmin()
    return array[idx]

path = 'PresetColours/'+palette

files = os.listdir(path)
desSize = 1
images = []
avgs = []

#   Stores all image paths, resizes image sizes, gets average RGB arrays from images

for f in files:
    try:
        im = Image.open(path+"/"+f)
        im = im.resize((desSize,desSize))
        im.save("bin/"+f)
        images.append(im)
        color_thief = ColorThief("bin/"+f)
        dominant_color = color_thief.get_color(quality=1)
        avgs.append(dominant_color)
    except:
        print("problem with " + f)

print("Processed Images...")

ref = Image.open("Reference.png")
pix = ref.load()
orw,orh = ref.size
ime = Image.new(mode="RGB", size=(orw,orh))
back_im = ime.copy()
placements = []

print("Comparing...")

workLoad = floor(orh/desSize)*floor(orw/desSize)
workedThrough = 0
print(workLoad)
#   Compares the averages/dominant colours of each motif and selects and pastes the best one onto the image

for y in range(floor(orh/desSize)):
    for x in range(floor(orw/desSize)):
        confidences = []
        rgb = (pix[x*desSize,y*desSize][0],pix[x*desSize,y*desSize][1],pix[x*desSize,y*desSize][2])
        for i in avgs:
            confidences.append(arrayConfidence(rgb,i))
        closest = images[confidences.index(min(confidences))]
        placements.append(closest)
        back_im.paste(closest, (x*desSize, y*desSize))
        workedThrough += 1

        if(workedThrough % round(workLoad/10) == 0):
            print(workedThrough, "/", workLoad, " Processed")
filename = str(randint(1,1000))

back_im.save("output/"+filename+".png")
back_im.save("recentOutput.png")
#   Clear bin
files = glob.glob('Bin/*')
for f in files:
    os.remove(f)
print("Emptied bin")

print("Saved as "+filename)